<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/config.php');// подгружаем настройки
require_once($_SERVER['DOCUMENT_ROOT'].'/php/sd_clones.inc.php');// 
mb_internal_encoding('UTF-8');// по умолчанию все функции должны работать с UTF кодировкой
mb_regex_encoding('UTF-8');// по умолчанию все функции для регулярных выражений будут работать с UTF кодировкой
setlocale (LC_ALL, 'ru_RU.UTF8');
ini_set('pcre.backtrack_limit',5000000);// для лучше работы регулярных выражений
if ($sd_config['debug_disabled']==1) { error_reporting(0); }// если требуется скрыть все ошибки
$file_type_content=array('text/html','text/xml','application/xml','rss+xml');
// основное
$data_request=$_REQUEST;// данные из форм
$data_get=sdf_str_delete($_SERVER['REQUEST_URI'],1,1);// данные из командной строки
$url_key='/'.$data_get;
$content=sdf_url_content('http://'.$sd_config['source_domain'].$url_key);
$pos_int=0; $c=sizeof($file_type_content);
for ($it=0;$it<$c;$it++)
{ $pos=stripos($content['header']['content_type'],$file_type_content[$it]);// пытаемся найти строку в подстроке без учета регистра
  if ($pos!==false) { $pos_int=$pos+1; break; }// если найден искомый результат, то прописываем в строке, где найден элемент
}
/*
$pos=stripos($content['header']['content_type'],'text/xml');// пытаемся найти строку в подстроке без учета регистра
if ($pos!==false) { $pos_int=$pos+1; }// если найден искомый результат, то прописываем в строке, где найден элемент
$pos=stripos($content['header']['content_type'],'application/xml');// пытаемся найти строку в подстроке без учета регистра
if ($pos!==false) { $pos_int=$pos+1; }// если найден искомый результат, то прописываем в строке, где найден элемент
echo $content['header']['content_type'];
*/
$more=0;
// if (($pos_int==0) and ($content['header']['http_code']!=200) and ('http://'.$sd_config['source_domain'].'/'=='http://'.$sd_config['source_domain'].$url_key))
if (($pos_int==0) and ($content['header']['http_code']!=200))
{ $content['content']='';
  $content['content'].='<html>'."\n";
  $content['content'].='<head>'."\n";
  $content['content'].='<meta http-equiv="content-type" content="text/html; charset=utf-8" />'."\n";
  $content['content'].='</head><body>'."\n";
  $content['content'].='Сайт на реконструкции. Код: '.$content['header']['http_code'].' {links_all}';// записываем полученные данные
  $content['content'].='</body></html>'."\n";
  $more=1;
}
if (($pos_int==0) and ($more==0))
{ header('Content-type: '.$content['header']['content_type']);
  echo $content['content'];
  die;
}
if ((($sd_config['source_charset']=='cp1251') or ($sd_config['source_charset']=='windows-1251')) and ($more==0))
{ $content['content']=iconv('cp1251','utf-8',$content['content']);// конвертируем весь контент с cp1251 в UTF-8
}
$c=1; while ($c>0) { $content['content']=str_ireplace("\t",' ',$content['content'],$c); }// убираем табуляторы
$c=1; while ($c>0) { $content['content']=str_ireplace("\n\n","\n",$content['content'],$c); }// убираем двойный переводы строк
$c=1; while ($c>0) { $content['content']=str_ireplace('&nbsp;',' ',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace('  ',' ',$content['content'],$c); }// убираем двойные пробелы
$c=1; while ($c>0) { $content['content']=str_ireplace(' language="javascript"','',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' align=left','',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' target=_blank','',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' target="_blank"','',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' title=""','',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' <ul','<ul',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' </ul','</ul',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' <li','<li',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' </li','</li',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' <p','<p',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' <h','<h',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace('&hellip;','…',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace('&laquo;','«',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace('&raquo;','»',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace('www.','',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' ,',', ',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' <td','<td',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace('</td> ','</td>',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' </td>','</td>',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace('</tr> ','<tr>',$content['content'],$c); }
$c=1; while ($c>0) { $content['content']=str_ireplace(' </tr>','<tr>',$content['content'],$c); }
//$c=1; while ($c>0) { $content['content']=str_ireplace('href=" ','href="',$content['content'],$c); }

$content['content']=@preg_replace('#<a(.*)(href=[\'](.*)[\'])(.*)>#Ui','<a${1}href="${3}"${4}>',$content['content']);// выправляем хреновые ковычки в ссылках
$content['content']=@preg_replace('#<a(.*)(href=)(.*)([\s,>])#Ui','<a${1}href="${3}"${4}',$content['content']);// выправляем ссылки вообще без ковычек
$content['content']=@preg_replace('#<a(.*)(href="")(.*)""#Ui','<a${1}href="${3}"',$content['content']);// выправляем ссылки с двойными ковычками

// $c=1; while ($c>0) { $content['content']=str_ireplace('href=""','href="',$content['content'],$c); }
// $c=1; while ($c>0) { $content['content']=str_ireplace('" ">','">',$content['content'],$c); }
$content['content']=str_ireplace('windows-1251','utf-8',$content['content']);
$content['content']=str_ireplace($sd_config['source_domain'],sd_domain,$content['content']);// замена всех url источника на нужный домен

// $content['content']=@preg_replace('#&quot;([^\t]*)&quot;#Ui','«${1}»',$content['content']);// корректируем ковычки
// удаляем все внешние ссылки с http
@preg_match_all('#<a(.*)href="http://(.*)"(.*)>([^\t]*)</a>#Ui',$content['content'],$url_);
$count2_=count($url_[2]);
$tt=0;
while($tt<$count2_)
{ $b=sdf_str_pos($url_[2][$tt],sd_domain);
  if ($b==0)
  { $rep='<a'.$url_[1][$tt].'href="http://'.$url_[2][$tt].'"'.$url_[3][$tt].'>'.$url_[4][$tt].'</a>';
    $rr=$url_[4][$tt];
    $rr=str_replace("\n",' ',$rr);
    $rr=str_replace("\r",' ',$rr);
    $rr=str_replace('  ',' ',$rr);
    $content['content']=str_ireplace($rep,$rr,$content['content']);
  }
  $tt++;
}
// удаляем все внешние ссылки с https
@preg_match_all('#<a(.*)href="https://(.*)"(.*)>([^\t]*)</a>#Ui',$content['content'],$url_);
$count2_=count($url_[2]);
$tt=0;
while($tt<$count2_)
{ $rep='<a'.$url_[1][$tt].'href="https://'.$url_[2][$tt].'"'.$url_[3][$tt].'>'.$url_[4][$tt].'</a>';
  $rr=$url_[4][$tt];
  $rr=str_replace("\n",' ',$rr);
  $rr=str_replace("\r",' ',$rr);
  $rr=str_replace('  ',' ',$rr);
  $content['content']=str_ireplace($rep,$rr,$content['content']);
  $tt++;
}
// Глобальные замены из файла замен
if ((!isset($sd_config['file_replace_global_disabled'])) or ($sd_config['file_replace_global_disabled']!=1))
{ $ddg1='';
  $file_name_replace=$_SERVER['DOCUMENT_ROOT'].'/file_replace_global.txt';// где хроняться локальные замены
  $file_handle=fopen($file_name_replace,'r');// открываем файл
  $file_size=filesize($file_name_replace);// узнаем размер файла
  if ($file_size>0) { $ddg1=fread($file_handle,$file_size); }// если файл не пустой, то читаем данные
  fclose($file_handle);// закрываем файл
  preg_match_all('#<replace>(.*)</replace>#Ui',$ddg1,$ddg);// находим все замены
  $count_=count($ddg[1]);
  $it=0;
  while ($it<$count_)
  { $ex=explode('<|||>',$ddg[1][$it]);
    if ($ex[0]=='') { $it++; continue; }// если не коректна запись
    if ($ex[2]=='disabled') { $it++; continue; }// если запись отключена для обработки
    if ($ex[2]=='regex')
    { $exx=str_ireplace('#','\#',$ex[0]);
      $content['content']=preg_replace('#'.$exx.'#Ui',$ex[1],$content['content']);
    }
    else
    { $c=1;
      while ($c>0)
      { $content['content']=str_ireplace($ex[0],$ex[1],$content['content'],$c);
      }
    }
    $it++;
  }
}
// Основные замены из файла замен
$dd1='';
$file_name_replace=$_SERVER['DOCUMENT_ROOT'].'/file_replace.txt';// где хроняться локальные замены
$file_handle=fopen($file_name_replace,'r');// открываем файл
$file_size=filesize($file_name_replace);// узнаем размер файла
if ($file_size>0) { $dd1=fread($file_handle,$file_size); }// если файл не пустой, то читаем данные
fclose($file_handle);// закрываем файл
preg_match_all('#<replace>(.*)</replace>#Ui',$dd1,$dd);// находим все замены
$count_=count($dd[1]);
$it=0;
while ($it<$count_)
{ $ex=explode('<|||>',$dd[1][$it]);
  if ($ex[0]=='') { $it++; continue; }// если не коректна запись
  if ($ex[2]=='disabled') { $it++; continue; }// если запись отключена для обработки
  if ($ex[2]=='regex')
  { $exx=str_ireplace('#','\#',$ex[0]);
    $content['content']=preg_replace('#'.$exx.'#Ui',$ex[1],$content['content']);
  }
  else
  { $c=1;
    while ($c>0)
    { $content['content']=str_ireplace($ex[0],$ex[1],$content['content'],$c);
    }
  }
  $it++;
}
// обработка бирж
$pos=stripos($content['content'],'{links_all}');// пытаемся найти строку в подстроке без учета регистра
$links_all_position=0;
if ($pos!==false) { $links_all_position=$pos+1; }// если найден искомый результат, то прописываем в строке, где найден элемент
// если общего линка нет
if ($links_all_position==0)// 
{ // если включена биржа sape.ru
  $ll_sape='';
  if ($sd_config['sape']==1)// если сапа разрешена
  { define('_SAPE_USER',$sd_config['sape_hash'] );
    include($_SERVER['DOCUMENT_ROOT'].'/exchanges/sape/sape.php');
    $o=array();
    $o['charset']='UTF-8';
    $o['force_show_code']=($sd_config['debug_disabled'])?0:1;
    $sape=new SAPE_client($o);
    $ll_sape=$sape->return_links();
  }
  $content['content']=str_replace('{sape}',$ll_sape,$content['content']);
  // если включена биржа linkfeed.ru
  $ll_linkfeed='';
  if ($sd_config['linkfeed']==1)
  { define('LINKFEED_USER',$sd_config['linkfeed_hash']);
    include_once($_SERVER['DOCUMENT_ROOT'].'/exchanges/linkfeed/linkfeed_articles.php');
    // array( 'force_show_code' => true)// для демонстрации что код установлен верно
    $linkfeed = new LinkfeedClient();
    $ll_linkfeed=$linkfeed->return_links();
  }
  $content['content']=str_replace('{linkfeed}',$ll_linkfeed,$content['content']);
  // если включена биржа setlinks.ru
  $ll_setlinks='';
  if ($sd_config['setlinks']==1)
  { require_once($_SERVER['DOCUMENT_ROOT'].'/exchanges/setlinks/slclient.php');
    $sl = new SLClient();
    $ll_setlinks=$sl->GetLinks();
  }
  $content['content']=str_replace('{setlinks}',$ll_setlinks,$content['content']);
}
else// если ссылки выводяться через один общий теги links_all
{ // если включена биржа sape.ru
  $ll_links_all='';
  if ($sd_config['sape']==1)// если sape разрешена
  { define('_SAPE_USER',$sd_config['sape_hash'] );
    include($_SERVER['DOCUMENT_ROOT'].'/exchanges/sape/sape.php');
    $o=array();
    $o['charset']='UTF-8';
//    $o['force_show_code']=($sd_config['debug_disabled'])?0:1;
    $sape=new SAPE_client($o);
    $ll_links_all.=$sape->return_links().' ';
  }
  // если включена биржа linkfeed.ru
  if ($sd_config['linkfeed']==1)
  { define('LINKFEED_USER',$sd_config['linkfeed_hash']);
    include_once($_SERVER['DOCUMENT_ROOT'].'/exchanges/linkfeed/linkfeed_articles.php');
    $linkfeed = new LinkfeedClient();
    $ll_links_all.=$linkfeed->return_links().' ';
  }
  // если включена биржа setlinks.ru
  if ($sd_config['setlinks']==1)
  { require_once($_SERVER['DOCUMENT_ROOT'].'/exchanges/setlinks/slclient.php');
    $sl=new SLClient();
    $ll_links_all.=$sl->GetLinks().' ';
  }
  if (trim($ll_links_all)!='')
  { $content['content']=str_replace('{links_all}',$sd_config['links_all_description'].$ll_links_all,$content['content']);
  }
  else
  { $content['content']=str_replace('{links_all}','<!-- test all links -->',$content['content']);
  }
}
// если включена биража mainlink.ru
$ll_mainlink='';
if ($sd_config['mainlink']==1)
{ include($_SERVER['DOCUMENT_ROOT'].'/exchanges/mainlink/ml.php');
//  $ml->Set_Config(array('debugmode'=>$sd_config['debug_disabled']));
//  $mlcfg=array('span'=>true,'style_span'=>'color:#cc6666;width:auto;padding:5px;text-align:left;font-size:12px;background:#ffffff;display:block;border:1px solid #434343','style'=>'color:#103399','style_header'=>'padding:0 0 10px 0;display:block');
//  $ml->Set_Config($mlcfg);
  $ll_mainlink=$ml->Get_Links();
}
$content['content']=str_replace('{mainlink}',$ll_mainlink,$content['content']);
// если включена биража trustlink.ru
$ll_trustlink='';
if ((isset($sd_config['trustlink'])) and ($sd_config['trustlink']==1))
{ define('TRUSTLINK_USER',$sd_config['trustlink_hash']);
  require_once($_SERVER['DOCUMENT_ROOT'].'/exchanges/trustlink/trustlink.php');
  $o=array();
  $o['charset']='utf-8';//кодировка сайта
  $trustlink=new TrustlinkClient($o);
  $ll_trustlink=$trustlink->build_links();
}
$content['content']=str_replace('{trustlink}',$ll_trustlink,$content['content']);
$content['content']=str_replace('{year}',date('Y',time()),$content['content']);
$content['content']=str_replace('{domain}',sd_domain,$content['content']);
$content['content']=str_replace('<script type="text/javascript"><!--','<script type="text/javascript">',$content['content']);
$content['content']=preg_replace('#<script type="text/javascript">([\n,\s,\r]*)</script>#Ui','',$content['content']);
$content['content']=preg_replace('#<noindex>([\n,\s,\r]*)</noindex>#Ui','',$content['content']);
$content['content']=preg_replace('# media="(all|screen)"#Ui','',$content['content']);
$li='';
$li.='<script type="text/javascript">'."\n";
$li.='document.write(\'<img src="http://counter.yadro.ru/hit?t14.11;r\'+escape(document.referrer)+((typeof(screen)==\'undefined\')?\'\':\';s\'+'."\n";
$li.='screen.width+\'*\'+screen.height+\'*\'+(screen.colorDepth?screen.colorDepth:screen.pixelDepth))+\';u\'+'."\n";
$li.='escape(document.URL)+\';\'+Math.random()+\'" alt="" width="0" height="0" />\');'."\n";
$li.='</script>'."\n";
$content['content']=str_replace('{li}',$li,$content['content']);

$c=1; while ($c>0) { $content['content']=str_ireplace('  ',' ',$content['content'],$c); }// убираем двойные пробелы
$c=1; while ($c>0) { $content['content']=str_ireplace("\n\n","\n",$content['content'],$c); }// убираем двойный переводы строк

$content['header']['content_type']=str_ireplace('windows-1251','utf-8',$content['header']['content_type']);
$content['header']['content_type']=str_ireplace('cp1251','utf-8',$content['header']['content_type']);

header('Content-type: '.$content['header']['content_type']);
// echo $content['header']['content_type'];
echo $content['content'];
?>