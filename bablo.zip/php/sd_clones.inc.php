<?php
// _____________________________________________________________________________
function sdf_url_content($_url)
// Выполняет: Закачку контента по указанному url
// Возвращает: текстовой контент с указанного url
// $_url - ссылка на страницу которую требуется скачать, и выдать в переменную
{
$r=array();
$r['content']='';// возвращаемый контент страницы по умолчанию
$r['header']='';// возвращаемый заголовок по умолчанию
$r['error']=0;// возвращаемый код ошибки по умолчанию
$options=curl_init();// инициализация опций для корректного скачивания файла
curl_setopt($options,CURLOPT_URL,$_url);// прописываем нужный url
curl_setopt($options,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417 Firefox/4.0.0');// каким браузером представляться
curl_setopt($options,CURLOPT_TIMEOUT,60);// максимальное время выполнения операции в секундах
curl_setopt($options,CURLOPT_MAXCONNECTS,1);// Максимальное количество постоянных соединений
// curl_setopt($options,CURLOPT_COOKIEJAR,$_SERVER['DOCUMENT_ROOT'].'/logs/cookie');
// curl_setopt($options,CURLOPT_COOKIEFILE,$_SERVER['DOCUMENT_ROOT'].'/logs/cookie');
curl_setopt($options,CURLOPT_AUTOREFERER,1);// автоматически ставить REFERER
curl_setopt($options,CURLOPT_SSL_VERIFYPEER,0);// отключить подстановку сертификатов
curl_setopt($options,CURLOPT_SSL_VERIFYHOST,0);// отключение проверки ssl хоста
$loops=1;// стартовый номер петля при переходах 
$loops_max=20;// максимально возможное количество петель, mod_rewrite
curl_setopt($options,CURLOPT_HEADER,1);// при запросе возвращать заголовок сервера (header)
curl_setopt($options,CURLOPT_RETURNTRANSFER,1);// возвращать результат в переменную
while ($loops<$loops_max)
{ $data=@curl_exec($options);// выполняем запрос с подавлением ошибок
  $header=@curl_getinfo($options);// получаем информацию о заголовке
  @list($location,$data)=@explode("\r\n\r\n",$data,2);// отделяем заголовок от основного контента
  if (($header['http_code']==301)||($header['http_code']==302))// если встретили код перенаправления
  { preg_match('#(Location:)(.*)#i',$location,$url_);// узнаем куда нас послали
    if (isset($url_[2])) { $url=trim($url_[2]); } else { $url=''; }// вырезаем ключевые слова
    if ($url=='')// если url не вырезался, то есть нас послали не корректно, то
    { $r['error']=1;// прописываем код ошибки
      break;// прекращаем работу цикла
    }
    curl_setopt($options,CURLOPT_URL,$url);// прописываем новый url
    $loops++;// увеличиваем номер петли
    continue;// продолжаем цикл, уходим на начало
  }
  if ($header['http_code']==200)// если получаем контент
  { $r['content']=$data;// записываем полученные данные
    $r['header']=$header;// записываем заголовок
    break;// прекращаем цикл
  }
  else
  { $r['content']='';
    $r['header']=$header;// записываем заголовок
    break;
  }
}
return $r;// выдаем полученные данные
}
// _____________________________________________________________________________
function sdf_str_delete($_string,$_position,$_count)
// Выполняет: Удаление из строки нужное кол-во символов с указанной позиции
// Возвращает: строку с удаленным символами
// $_string - входящая строка
// $_position - позиция в строке
// $_count - кол-во удаляемых символов
{
$r=substr_replace($_string,'',($_position-1),$_count);
return $r;
}
// _____________________________________________________________________________
function sdf_str_pos($_string,$_mask='')
// Выполняет: Поиск подстроки в строке в (UTF кодировке)
// Возвращает: номер позиции в строке, 0 - вхождения нет
// $_string - строка, где требуется производить поиск
// $_mask - перечень слов требующиеся для поиска, разделителем является |
{
$r=0;// по умолчанию искомой подстроки в строке нет
$array_mask=explode('|',$_mask);// разбиваем подструку на элементы если таковые имеются
$c=count($array_mask);// узнаем количество элементов для поиска
$it=0;
while ($it<$c)// пройтись по всем элементам
{ $pos=mb_stripos($_string,trim($array_mask[$it]),0,'utf-8');// пытаемся найти строку в подстроке без учета регистра
  if ($pos!==false)// если найден искомый результат
  { $r=$pos+1;// прописываем в строке, где найден элемент
    break;// прекращаем дальнейший поиск
  }
  $it++;// пеходим к следующему элементу для поиска
}
return $r;
}
// _____________________________________________________________________________
function sdf_page_error($_number)
{
header('HTTP/1.0 404 Not Found');
header('Status: 404 Not Found');
$r='';
$r.='<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">';
$r.='<html><head><title>404 Not Found</title></head><body><h1>Not Found</h1></body></html>';
echo $r;
die;
}
// _____________________________________________________________________________
function sdf_page_stop($_text)
{
$r='';
$r.='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'."\n";
$r.='<html xmlns="http://www.w3.org/1999/xhtml">'."\n";
$r.='<head>'."\n";
$r.='<meta http-equiv="content-type" content="text/html; charset=utf-8" />'."\n";
$r.='<title>Page Stop</title>'."\n";
$r.='</head>'."\n";
$r.='<body>'."\n";
$r.='<h1 style="color:#F00; text-align:center;">Page Stop</h1>'."\n";
$r.='<h2 style="text-align:center;">'.$_text.'</h2>'."\n";
$r.='</body>'."\n";
$r.='</html>'."\n";
echo $r;
die;
}
// _____________________________________________________________________________
function sdf_cache_save($_file_name,$_page,$_header='')
// сохранение контента в кэш
{
// global $config;
// if ( $config['cache'] !== true or empty($code) or empty($name) or strlen($code) > $config['maxsizecache'] ) { return false; }
$file_name=md5($_file_name);
// if ( cache2($name) )
// { $time=time()+$config['time2cache'];
// }
// else
// { $time=time()+$config['timecache'];
// }
$time=0;
$r=0;
$f=fopen($_SERVER['DOCUMENT_ROOT'].'/cache/'.$file_name,'w+');
if (!$f) { return $r; }
$head='#header{time download:'.$time.'}{headers:'.$_header.'}{file_name:'.$_file_name.'}'."\n";
fwrite($f,$head.$_page);
fclose($f);
$r=1;
return $r;
}
// _____________________________________________________________________________
function sdf_ifree_exchange($_content,$_config)
{
$r=$_content;
// попытка обработать SEO ссылки от Sape
if ($_config['hash_code_sape']!='')// если указан хэш код sape
{ if (!defined('_SAPE_USER')){ define('_SAPE_USER',$_config['hash_code_sape']); }
  require_once($_SERVER['DOCUMENT_ROOT'].'/exchanges/sa_'._SAPE_USER.'/sape.php'); 
  $o=array();
  $o['charset']='UTF-8';
  $o['force_show_code']=true;
  $sape=new SAPE_client($o);
  $r=str_ireplace('{sape1}',$sape->return_links(1),$r,$c);
  $r=str_ireplace('{sape2}',$sape->return_links(1),$r,$c);
  $r=str_ireplace('{sape3}',$sape->return_links(1),$r,$c);
  $r=str_ireplace('{sape4}',$sape->return_links(1),$r,$c);
  $r=str_ireplace('{sape5}',$sape->return_links(),$r,$c);
}
// попытка обработать SEO ссылки от LinkFeed
if ($_config['hash_code_linkfeed']!='')// если указан хэш код sape
{ define('LINKFEED_USER',$_config['hash_code_linkfeed']);
  require_once($_SERVER['DOCUMENT_ROOT'].'/exchanges/li_'.$_config['hash_code_linkfeed'].'/linkfeed.php'); 
  $linkfeed=new LinkfeedClient();
  $r=str_ireplace('{linkfeed1}',$linkfeed->return_links(1),$r,$c);
  $r=str_ireplace('{linkfeed2}',$linkfeed->return_links(1),$r,$c);
  $r=str_ireplace('{linkfeed3}',$linkfeed->return_links(1),$r,$c);
  $r=str_ireplace('{linkfeed4}',$linkfeed->return_links(1),$r,$c);
  $r=str_ireplace('{linkfeed5}',$linkfeed->return_links(),$r,$c);
}
return $r;
}
// _____________________________________________________________________________
function sdf_links_correct($_text)
// Выполняет: корректировку ссылок на основе входящего текста
// Возвращает: откорректированные текст
{
$r=$_text;
$r=@preg_replace('#<a (.*)(href=[\'](.*)[\'])(.*)>#Ui','<a ${1}href="${3}"${4}>',$r);// выправляем хреновые ковычки в ссылках
$r=preg_replace('#<a (.*)(href=)(.*)([\s,>])#Ui','<a ${1}href="${3}"${4}',$r);// выправляем ссылки вообще без ковычек
$r=preg_replace('#<a (.*)(href="")(.*)""#Ui','<a ${1}href="${3}"',$r);// выправляем ссылки с двойными ковычками
return $r;
}
// _____________________________________________________________________________
function sd_url_content($_url)
// Выполняет: Закачку контента по указанному url
// Возвращает: текстовой контент с указанного url
// $_url - ссылка на страницу которую требуется скачать, и выдать в переменную
{
// корректируем ссылку
$url=$_url;
$url=str_ireplace('http://','',$url);
$url='http://'.$url;
$r=array();
$r['content']='';// возвращаемый контент страницы по умолчанию
$r['header']='';// возвращаемый заголовок по умолчанию
$r['error']=0;// возвращаемый код ошибки по умолчанию
$options=curl_init();// инициализация опций для корректного скачивания файла
curl_setopt($options,CURLOPT_URL,$url);// прописываем нужный url
curl_setopt($options,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3');// каким браузером представляться
curl_setopt($options,CURLOPT_TIMEOUT,60);// максимальное время выполнения операции в секундах
curl_setopt($options,CURLOPT_MAXCONNECTS,1);// Максимальное количество постоянных соединений
// curl_setopt($options,CURLOPT_COOKIEJAR,$_SERVER['DOCUMENT_ROOT'].'/logs/cookie');
// curl_setopt($options,CURLOPT_COOKIEFILE,$_SERVER['DOCUMENT_ROOT'].'/logs/cookie');
curl_setopt($options,CURLOPT_AUTOREFERER,1);// автоматически ставить REFERER
curl_setopt($options,CURLOPT_SSL_VERIFYPEER,0);// отключить подстановку сертификатов
curl_setopt($options,CURLOPT_SSL_VERIFYHOST,0);// отключение проверки ssl хоста
$loops=1;// стартовый номер петля при переходах 
$loops_max=20;// максимально возможное количество петель, mod_rewrite
curl_setopt($options,CURLOPT_HEADER,1);// при запросе возвращать заголовок сервера (header)
curl_setopt($options,CURLOPT_RETURNTRANSFER,1);// возвращать результат в переменную
while ($loops<$loops_max)
{ $dd=@curl_exec($options);// выполняем запрос с подавлением ошибок
  if (!isset($dd))// если данные не получены
  { $r['error']=1;// прописываем код ошибки
    break;
  }
  $arr=explode("\r\n\r\n",$dd,2);// выделяем из
  $location='';
  if (isset($arr[0])) { $location=$arr[0]; }
  if (!isset($arr[1]))
  { $r['error']=1;// прописываем код ошибки
    break;
  }
  $data=$arr[1];
  $header=@curl_getinfo($options);// получаем информацию о заголовке
  if (($header['http_code']==301)||($header['http_code']==302))// если встретили код перенаправления
  { preg_match('#(Location:)(.*)#i',$location,$url_);// узнаем куда нас послали
    if (isset($url_[2])) { $url1=trim($url_[2]); } else { $url1=''; }// вырезаем ключевые слова
    if ($url1=='')// если url не вырезался, то есть нас послали не корректно, то
    { $r['error']=1;// прописываем код ошибки
      break;// прекращаем работу цикла
    }
    curl_setopt($options,CURLOPT_URL,$url1);// прописываем новый url
    $loops++;// увеличиваем номер петли
    continue;// продолжаем цикл, уходим на начало
  }
  else// если получаем контент
  { // $data;// записываем полученные данные
    $r['content']=$data;// записываем полученные данные
    $r['header']=$header;// записываем заголовок
    break;// прекращаем цикл
  }
}
return $r;// выдаем полученные данные
}
?>