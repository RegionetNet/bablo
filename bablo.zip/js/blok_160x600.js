/* 160X600 */
google_ad_client = "ca-pub-1234567";
google_ad_slot = "1234567";
google_ad_width = 160;
google_ad_height = 600;